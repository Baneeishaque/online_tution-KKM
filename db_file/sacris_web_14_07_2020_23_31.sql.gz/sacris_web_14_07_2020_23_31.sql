-- MySQL dump 10.13  Distrib 5.6.47, for Linux (x86_64)
--
-- Host: localhost    Database: sacris_web
-- ------------------------------------------------------
-- Server version	5.6.47-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `passowrd` varchar(50) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` (`admin_id`, `username`, `passowrd`) VALUES (1,'admin','admin');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assigns`
--

DROP TABLE IF EXISTS `assigns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assigns` (
  `assign_id` int(11) NOT NULL AUTO_INCREMENT,
  `teacher_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  PRIMARY KEY (`assign_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assigns`
--

LOCK TABLES `assigns` WRITE;
/*!40000 ALTER TABLE `assigns` DISABLE KEYS */;
INSERT INTO `assigns` (`assign_id`, `teacher_id`, `subject_id`) VALUES (1,1,3),(2,12,7),(3,12,7);
/*!40000 ALTER TABLE `assigns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `batchs`
--

DROP TABLE IF EXISTS `batchs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `batchs` (
  `batch_id` int(11) NOT NULL AUTO_INCREMENT,
  `batch_name` varchar(5) NOT NULL,
  `stream_id` int(11) NOT NULL,
  PRIMARY KEY (`batch_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `batchs`
--

LOCK TABLES `batchs` WRITE;
/*!40000 ALTER TABLE `batchs` DISABLE KEYS */;
INSERT INTO `batchs` (`batch_id`, `batch_name`, `stream_id`) VALUES (3,'b1',3),(6,'C2A',24),(7,'C2B',24),(8,'C2C',24),(9,'H2A',24),(10,'H2B',24);
/*!40000 ALTER TABLE `batchs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `courses`
--

DROP TABLE IF EXISTS `courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `courses` (
  `course_id` int(11) NOT NULL AUTO_INCREMENT,
  `course_name` varchar(50) NOT NULL,
  PRIMARY KEY (`course_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `courses`
--

LOCK TABLES `courses` WRITE;
/*!40000 ALTER TABLE `courses` DISABLE KEYS */;
INSERT INTO `courses` (`course_id`, `course_name`) VALUES (2,'HSE'),(3,'DEGREE'),(4,'P G DEGREE');
/*!40000 ALTER TABLE `courses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notes`
--

DROP TABLE IF EXISTS `notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notes` (
  `note_id` int(11) NOT NULL AUTO_INCREMENT,
  `teacher_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `description` varchar(150) NOT NULL,
  `file` varchar(50) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`note_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notes`
--

LOCK TABLES `notes` WRITE;
/*!40000 ALTER TABLE `notes` DISABLE KEYS */;
INSERT INTO `notes` (`note_id`, `teacher_id`, `subject_id`, `title`, `description`, `file`, `status`) VALUES (1,1,3,'1st ','ghgfdhfhgd','kkm demo face.jpg',1),(2,1,3,'1st ','ghgfdhfhgd','kkm demo face.jpg',0);
/*!40000 ALTER TABLE `notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `streams`
--

DROP TABLE IF EXISTS `streams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `streams` (
  `stream_id` int(11) NOT NULL AUTO_INCREMENT,
  `stream_name` varchar(50) NOT NULL,
  `course_id` int(11) NOT NULL,
  PRIMARY KEY (`stream_id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `streams`
--

LOCK TABLES `streams` WRITE;
/*!40000 ALTER TABLE `streams` DISABLE KEYS */;
INSERT INTO `streams` (`stream_id`, `stream_name`, `course_id`) VALUES (3,'1st BA English',3),(4,'1st BA SOCIOLOGY',3),(5,'1st BA ECONOMICS',3),(6,'1sT BA PSYCHOLOGY',3),(7,'1sT BCOM-A',3),(8,'1st BCOM-B',3),(9,'1st BA ENGLISH',3),(10,'1st BA English',3),(11,'2nd BCOM-A',3),(12,'2nd BA ENGLISH',3),(13,'2nd BA SOCIOLOGY',3),(14,'2nd BA PSYCHOLOGY',3),(15,'3rd BCOM CO-OPERATION',3),(16,'3rd BCOM FINANCE',3),(26,'3rd BCOM ',3),(18,'3rd BA ENGLISH',3),(19,'3rd BA SOCIOLOGY',3),(20,'3rd BA PSYCHOLOGY',3),(21,'1st MA ENGLISH  ',4),(22,'1st MA ECONOMICS',4),(23,'1st MCOM',4),(24,'COMMERCE',2),(25,'HUMANITIES',2),(27,'2nd BA PSYCHOLOGY',3),(28,'3rd BA PSYCHOLOGY',3);
/*!40000 ALTER TABLE `streams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `students` (
  `student_id` int(11) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(50) NOT NULL,
  `mobile_number` varchar(15) NOT NULL,
  `email_address` varchar(50) NOT NULL,
  `studying_class` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `batch_number` varchar(5) NOT NULL DEFAULT 'NA',
  `additional_mobile` varchar(100) DEFAULT NULL,
  `additional_email` varchar(150) DEFAULT NULL,
  `photo` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`student_id`),
  UNIQUE KEY `mobile_number` (`mobile_number`),
  UNIQUE KEY `email_address` (`email_address`)
) ENGINE=MyISAM AUTO_INCREMENT=115 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `students`
--

LOCK TABLES `students` WRITE;
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` (`student_id`, `full_name`, `mobile_number`, `email_address`, `studying_class`, `status`, `username`, `password`, `batch_number`, `additional_mobile`, `additional_email`, `photo`) VALUES (4,'Banee Ishaque','09446827219','baneeishaque@gmail.com',3,2,'kkms997','kkms997','3','','','sampleImage09.jpg'),(5,'NAME','9497100500','bobyjohn007@gmail.com',24,1,'kkms254','pw254','6','','','001.jpg'),(6,'NAME','9526513344','kkmcollegetir@gmail.com',24,0,'','','6',NULL,NULL,NULL),(7,'MOhammad sabir p','8089661187','mohasabirp1010@gmail.com',15,0,'','','',NULL,NULL,NULL),(8,'MUHAMED SHAMEEM NOOR','9562702033','shameemnoormks@gmail.com',13,0,'','','',NULL,NULL,NULL),(9,'Sharmina salam ','9207857715','sharminashaheed@gmail.com',16,0,'','','',NULL,NULL,NULL),(10,'M H KRISHNAVENI','8281030701','venitpz@gmail.com',13,0,'','','',NULL,NULL,NULL),(11,'AMRUTHA V','8589936358','amruthav766@gmaile.com',15,2,'kkms971','pw971','','8086005766','','WhatsApp Image 2020-07-07 at 11.08.00 PM.jpeg'),(12,'HUSNA SHIRIN .T','7558017999','husna.shirin79@mail.com',12,2,'kkms51','pw51','','','','WhatsApp Image 2020-07-07 at 11.08.00 PM.jpeg'),(13,'MUFEEDHA. Tk','7736567117','mufeedha139@gmail.com',19,0,'','','',NULL,NULL,NULL),(14,'Surya gokul k. P','8129445978','suryagokulkp@gmail.com',16,0,'','','',NULL,NULL,NULL),(15,'JASIM. V','9048481792','jasimvengaden@gmail.com',15,0,'','','',NULL,NULL,NULL),(16,'NAYANAMANJUSHA.M','9961407551','sa.nayanamanju0@gmail.com',15,0,'','','',NULL,NULL,NULL),(17,'SRUTHY K M','7902752284','nairsruthy711@gmail.com',16,2,'kkms73','pw73','','9746171096','','WhatsApp Image 2020-07-07 at 11.08.00 PM.jpeg'),(18,'MOHAMMED JEMSHEER PP','8593966940','jemsheertlr71@gmail.com',16,0,'','','',NULL,NULL,NULL),(19,'AYISHA MURSHIDA ','9567330651','kkmcollegetirur@gmail.com',18,0,'','','',NULL,NULL,NULL),(20,'ABDUL KALAM AZAD. PK','9048708910','abdulkalamazad048@gmail.com',13,0,'','','',NULL,NULL,NULL),(21,'ALIYA.T.K','9847482506','sajidaparayil313@gmail.com',19,0,'','','',NULL,NULL,NULL),(22,'MUHSINA FILDHA.CV','9567069079','muhsinafildha@gmail.com',18,2,'kkms665','pw665','','9847584666','','WhatsApp Image 2020-07-07 at 11.08.00 PM.jpeg'),(23,'SHAHAL BABU K','9061004100','shahalbinshareef@gmail.com',16,0,'','','',NULL,NULL,NULL),(24,'MOHAMMED ASHIQUE K K','9048420553','mohammedashiq767@gmail.com',11,2,'kkms463','pw463','','','','WhatsApp Image 2020-07-07 at 11.08.00 PM.jpeg'),(25,'ANEESHA PK','9562919509','aneeshapk07@gmail.com',18,2,'kkms287','pw287','','','','WhatsApp Image 2020-07-07 at 11.08.00 PM.jpeg'),(26,'Namitha tv','9496141893','namitharamesh84@gmail.com',12,2,'kkms388','pw388','','9847477893','','WhatsApp Image 2020-07-07 at 11.08.00 PM.jpeg'),(27,'BIJISHNA. Mk','8593970324','sudheeshpdosth@gmail.com',11,0,'','','',NULL,NULL,NULL),(28,'RISVANA NT','6282811232','thayyilshahina@gmail.com',13,0,'','','',NULL,NULL,NULL),(29,'MUBASHIRA PP','8593968040','mubimubashira118@gmail.com',12,0,'','','',NULL,NULL,NULL),(30,'Rafna mv','9946604122','rafnanunnu@gmail.com',13,0,'','','',NULL,NULL,NULL),(31,'FATHIMA NASRIN. K. K','9846032949','ninunasrin962@gmail.com',11,2,'kkms993','pw993','','9072576022','','WhatsApp Image 2020-07-07 at 11.08.00 PM.jpeg'),(32,'SUMAYYA FARSANA. K','8113940121','www.sumi53226@gmail.com',11,0,'','','',NULL,NULL,NULL),(33,'MUBEENA.C','8129112396','muhammedshibili1705@gmail.com',11,0,'','','',NULL,NULL,NULL),(34,'RAKHI.M','6235456232','raghi6235@gmail.com',12,2,'kkms182','pw182','','8606041305','','WhatsApp Image 2020-07-07 at 11.08.00 PM.jpeg'),(35,'HASNIYA.U','8593844874','hasniyau@gmail.com',13,0,'','','',NULL,NULL,NULL),(36,'SHAFANA.M','8075795393','shafana@gmail.com',12,0,'','','',NULL,NULL,NULL),(37,'Mohamed Haris NK','9946800259','harisq8403@gmail.com',15,0,'','','',NULL,NULL,NULL),(38,'RAFEENA BINSI','6238010567','refIarshu@gmail.come',12,2,'kkms177','pw177','','6282905904','','WhatsApp Image 2020-07-07 at 11.08.00 PM.jpeg'),(39,'RISHA THESNEEM','8589930498','shabirisha01@gmail.com',18,0,'','','',NULL,NULL,NULL),(40,'MUHAMMED SIYAD','9747585254','muthusiyad@gmail.com',11,0,'','','',NULL,NULL,NULL),(41,'MOHAMMED SHAMEER TK','8592953457','shashameer567@gmail.com',11,0,'','','',NULL,NULL,NULL),(42,'Limna jibin N','7902264948','limnalimna 168@gmile .com',13,0,'','','',NULL,NULL,NULL),(43,'MAJITHA','9567336373','kkmcollagetirur@gmail.com',15,0,'','','',NULL,NULL,NULL),(44,'JASEELA. E','8129702593','jaseelelanattil98@gmail',12,0,'','','',NULL,NULL,NULL),(45,'SRUTHY','9746171096','kkmcollegethiruur@gmail.com',16,0,'','','',NULL,NULL,NULL),(46,'JASEELA. E','9562687554','moideenkuttyelanattil984@gmil.com',12,0,'','','',NULL,NULL,NULL),(47,'SHAMNA KP','7034207060','nazarvp6292@gmail.com',13,0,'','','',NULL,NULL,NULL),(48,'Thabseera m ','9544070264','thabseerathabsi4@gmail.com',12,2,'kkms294','pw294','','9995060264','','WhatsApp Image 2020-07-07 at 11.08.00 PM.jpeg'),(49,'RESHMA','7994605383','rahulprha@gmail.com',18,0,'','','',NULL,NULL,NULL),(50,'HASNA SHERIN MP','9846630866','ashrafmp368@gmil.com',11,0,'','','',NULL,NULL,NULL),(51,'RASHIDA.P','9895802348','pkrashida767@gmail.com',12,0,'','','',NULL,NULL,NULL),(52,'JISHNI','7034899932','jishnishinu@gmail.com',18,0,'','','',NULL,NULL,NULL),(53,'WAFA SHAFEEDA','9995691668','musthafa.smooth@gmail.com',12,2,'kkms857','pw857','','9495595554','','WhatsApp Image 2020-07-07 at 11.08.00 PM.jpeg'),(54,'MUFEEDA.P.P','9605532509','mmd16320@gmail.com',18,0,'','','',NULL,NULL,NULL),(55,'FATHIMA MURSHIDA. T','9995448515','murshidatrr1234@gmail.com',11,0,'','','',NULL,NULL,NULL),(56,'IRFANA THESNI','7356165838','thesniirfana1@gmail.com',11,0,'','','',NULL,NULL,NULL),(57,'Muhammad sabik. Ck','9895360723','sabikck70@gmail.com',11,2,'kkms792','pw792','','9895659049///8139860023','','WhatsApp Image 2020-07-07 at 11.08.00 PM.jpeg'),(58,'Mohmmad fazil pt','949681977','fazil.pulikkathodi@gmail.com',15,0,'','','',NULL,NULL,NULL),(59,'SAFLA NASMIN. K','9061836350','saflanasmin@gmail.com',18,0,'','','',NULL,NULL,NULL),(60,'RAMEESA.A','8139016127','rameesaraminoushu@gmail.com',18,0,'','','',NULL,NULL,NULL),(61,'Mohamed shibil. P','8078106510','shibilmhd310@gmail.com',11,0,'','','',NULL,NULL,NULL),(62,'MOHAMMED SHIBLI','8136838674','Shibishazz9061@gmail.com',11,0,'','','',NULL,NULL,NULL),(63,'MISHAL. Pk','9645689835','mishalshalu45@gmail.com',16,0,'','','',NULL,NULL,NULL),(64,'SHAHINA PP','7902691347','shahishahina790@gmail.com',15,2,'kkms790','pw790','','9745567049','','WhatsApp Image 2020-07-07 at 11.08.00 PM.jpeg'),(65,'DILSHANA.P.P','8590292550','dilshanapp0@gmail.com',11,0,'','','',NULL,NULL,NULL),(66,'FATHIMA RIFA K','9895619990','kakkadavathkundungal@gmail.com',15,0,'','','',NULL,NULL,NULL),(67,'Muhammed fadhil NP','8129736046','fadhilmuhammedfadhil@gmail.com',11,0,'','','',NULL,NULL,NULL),(68,'Aswathy.V','9072055292','Vaswathy773@gmail.com',15,2,'kkms849','pw849','','9846462970','','WhatsApp Image 2020-07-07 at 11.08.00 PM.jpeg'),(69,'JASILA. PP','9746336999','jasilapp71@gmail.com',12,0,'','','',NULL,NULL,NULL),(70,'SREETHUSHA.K','8075198276','ammumanuammumanu6@gmail.com',11,0,'','','',NULL,NULL,NULL),(71,'SOORYA K ','6238664534','surya97654324@gmail.com',13,0,'','','',NULL,NULL,NULL),(72,'CHITHRA NANNAT','8086004410','chithransachi75@gmail.com',15,2,'kkms259','pw259','','9048405875','','WhatsApp Image 2020-07-07 at 11.08.00 PM.jpeg'),(73,'Mohamed hashif v.p','9946749423','hashifhz885@gmail.com',19,0,'','','',NULL,NULL,NULL),(74,'Hairunisa cp','9072518314','hairunisa437@gmail.com',19,0,'','','',NULL,NULL,NULL),(75,'RAHLA FATHIMA V.P','9061414434','rahlanajwan@gmail.com',15,2,'kkms833','pw833','','9895729532','','WhatsApp Image 2020-07-07 at 11.08.00 PM.jpeg'),(76,'Ali jafsal','9645355981','aj7963360@gmail.com',15,0,'','','',NULL,NULL,NULL),(77,'ARUNy','7356441217','ammugiriammugiri06@gmail.com',11,0,'','','',NULL,NULL,NULL),(78,'ATHULYA','7034909411','haridasan66580369@gmail.com',11,0,'','','',NULL,NULL,NULL),(79,'JANNATHUL BUSHRA ','9539388189','jannathnp@gmail.com',11,0,'','','',NULL,NULL,NULL),(80,'SHABEER.PP','9947056424','ppshabeer567@gmail.com',26,2,'kkms322','pw322','','','','WhatsApp Image 2020-07-07 at 11.08.00 PM.jpeg'),(81,'SREESHNA. C','7510807017','sreeshnacrajan99@gmail.com',16,2,'kkms399','pw399','','8606853034','','WhatsApp Image 2020-07-07 at 11.08.00 PM.jpeg'),(82,'SEMEENA SANA P','9526732958','Sanshazsanshaz@gmail.com',16,0,'','','',NULL,NULL,NULL),(83,'MUFEEDHA.P.K','8281661029','mufeedhapk555@gmail.com',15,2,'kkms80','pw80','','','','WhatsApp Image 2020-07-07 at 11.08.00 PM.jpeg'),(84,'JANNATHUL BUSHRA','9567818924','rahilnp47@gmail.com',11,0,'','','',NULL,NULL,NULL),(85,'SHAHLI. Mp','9747480879','shahlimpshahli@gmail.com',11,0,'','','',NULL,NULL,NULL),(86,'FEMINA. T','8606265436','faisalsubu@gmail.com',16,0,'','','',NULL,NULL,NULL),(87,'SALEEKHA BEEVI K.P','8086300835','saleekhakp@gmail.com',15,2,'kkms346','pw346','','9048354443','','WhatsApp Image 2020-07-07 at 11.08.00 PM.jpeg'),(88,'SHIFANA','9562547462','shifana@emaile.com',13,0,'','','',NULL,NULL,NULL),(89,'HAFEEFA.P','9645109427','hafeefasaidalavi@gmail.com',19,0,'','','',NULL,NULL,NULL),(90,'THOYYIBA NASREEN. P','9526728691','nasreenthoyyiba@gmail.com',11,0,'','','',NULL,NULL,NULL),(91,'FEMlNA. K','9846148127','nazerkayakk123@gmail.com',15,0,'','','',NULL,NULL,NULL),(92,'JUNAIS','9061886977','jabirkoradjabi022@gmail.com',11,0,'','','',NULL,NULL,NULL),(93,'FATHIMA RIYA','9539879234','zzeniya527@gmail.com',18,0,'','','',NULL,NULL,NULL),(94,'RISHAD M','9744101029','rishurishad101029@gmail.com',11,0,'','','',NULL,NULL,NULL),(95,'VISHAK P','9847021818','vichuvishak419@gamail.com',11,0,'','','',NULL,NULL,NULL),(96,'Shameema PA','7994961266','shameemahariskt@gmail.com',19,0,'','','',NULL,NULL,NULL),(97,'ASNA. K','9048054435','www.kabeerk39148@gmail.com',11,0,'','','',NULL,NULL,NULL),(98,'SHUFEERA kc ','9526276952','shufishufeera@gemil.com',11,0,'','','',NULL,NULL,NULL),(99,'Nasla P. A','8086618033','musthafahajipa@gmail.com',19,0,'','','',NULL,NULL,NULL),(100,'FATHIMA FABEELA. M','9747933110','fabi@gmail.com',6,0,'','','',NULL,NULL,NULL),(101,'RIFANA NESRIN-k','9605674251','rifana96@gmail.com',6,0,'','','',NULL,NULL,NULL),(102,'FATHIMA SHARIN','9567420404','sharinsharip10@gmail.com',19,0,'','','',NULL,NULL,NULL),(103,'Farhanathesni E p','8943941995','mansoormanuzz...uzz@gmail.com',18,0,'','','',NULL,NULL,NULL),(104,'SHIFANA SHERIN.U3','9544872833','wwwshifuzzz@gmail.com',15,2,'kkms55','pw55','','','','WhatsApp Image 2020-07-07 at 11.08.00 PM.jpeg'),(105,'Asnath mol','9995978217','asnathpsy@gmail.com',28,0,'','','',NULL,NULL,NULL),(106,'Najmunnisa ','9746181680','Najmunnisa@email.com',11,0,'','','',NULL,NULL,NULL),(107,'Fathima. P','8943086737','pklfma21@gmail.com',28,0,'','','',NULL,NULL,NULL),(108,'MOHAMED MUNAVIR C','9447987817','munavi02@gmail.com',11,2,'kkms185','pw185','','9645217582','','WhatsApp Image 2020-07-07 at 11.08.00 PM.jpeg'),(109,'MUFLIHA MUSTHAFA T','9400514452','kkmcollege@gmail.com',20,0,'','','',NULL,NULL,NULL),(110,'Sahala sarin m','8129047221','shahlam821@gmail.com',15,0,'','','',NULL,NULL,NULL),(111,'BINASHIF P','7356155497','binashifbinu0085@gmail.com',15,0,'','','',NULL,NULL,NULL),(112,'Munshida','7356301011','munshidachinju@gmail.com',16,0,'','','',NULL,NULL,NULL),(113,'Busthana Sherin p','8943180660','busthanashiri@gmail.com',20,0,'','','',NULL,NULL,NULL),(114,'MUHAMMAD RISWAN KUNNATHEDATH','9645811247','risuriswan386279@gmail.com',26,0,'','','',NULL,NULL,NULL);
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subjects`
--

DROP TABLE IF EXISTS `subjects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subjects` (
  `subject_id` int(11) NOT NULL AUTO_INCREMENT,
  `stream_id` int(11) NOT NULL,
  `subject_name` varchar(50) NOT NULL,
  PRIMARY KEY (`subject_id`)
) ENGINE=MyISAM AUTO_INCREMENT=131 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subjects`
--

LOCK TABLES `subjects` WRITE;
/*!40000 ALTER TABLE `subjects` DISABLE KEYS */;
INSERT INTO `subjects` (`subject_id`, `stream_id`, `subject_name`) VALUES (2,3,'Malayalam'),(3,3,'English'),(4,7,'1st Semester-BUSINESS MANAGEMENT'),(5,7,'1st Semester-MANAGERIAL ECONOMICS'),(6,7,'1st Semester-TRANSACTIONS,ESSENTIAL ENGLISH LANGUA'),(7,7,'2nd Semester-FINANCIAL ACCOUNTING'),(8,7,'2nd Semester-MARKETING MANAGEMENT'),(9,7,'2nd Semester-WRITING FOR ACADEMIC AND PROFESSIONAL'),(10,7,'2nd Semester-ZEITGEIST READING ON CONTEMPORARY CUL'),(11,7,'2nd Semester-MALAYALAM'),(12,7,'2nd Semester-ARABIC'),(13,9,'2nd Semester-WRITING FOR ACADEMIC AND PROFESSIONAL'),(14,9,'2nd Semester-ZEITGEIST READING ON CONTEMPORARY CUL'),(15,9,'2nd Semester-READING PROSE'),(16,9,'2nd Semester-INTRODUCTION TO COMMUNICATION AND JOU'),(17,9,'2nd Semester-INTRODUCTION TO ELECTRONIC MEDIA AND '),(18,9,'2nd Semester-ARABIC'),(19,9,'2nd Semester-MALAYALAM'),(20,7,'2nd Semester-MALAYALAM'),(21,4,'2nd Semester-MALAYALAM'),(22,4,'2nd Semester-ARABIC'),(23,4,'2nd Semester-ZEITGEIST READING ON CONTEMPORARY CUL'),(24,4,'2nd Semester-WRITING FOR ACADEMIC AND PROFESSIONAL'),(25,4,'2nd Semester-INDIAN CONSTITUTION AND POLITICS:BASI'),(26,4,'2nd Semester-INTRODUCTION TO SOCIOLOGY'),(27,4,'2nd Semester-PSYCHOLOGICAL PROCESS Ist&IInd'),(28,11,'3rd Semester-BASIC NUMERICAL SKILLS'),(29,11,'3rd Semester-GENERAL INFORMATICS'),(30,11,'3rd Semester-BUSINESS REGULATIONS'),(31,11,'3rd Semester-CORPORATE ACCOUNTING'),(32,11,'3rd Semester-HUMAN RESOURCE MANAGEMENT'),(33,12,'3rd Semester-SIGNATURES:EXPRESSING THE SELF'),(34,12,'3rd Semester-READING DRAMA'),(35,12,'3rd Semester-READING FICTION'),(36,12,'3rd Semester-MALAYALAM'),(37,12,'3rd Semester-ARABIC'),(38,13,'3rd Semester-SIGNATURES:EXPRESSING THE SELF'),(39,13,'3rd Semester-MALAYALAM'),(40,13,'3rd Semester-ARABIC'),(41,13,'3rd Semester-SOCIAL INFORMATICS'),(42,13,'3rd Semester-FOUNDATIONS OF SOCIOLOGICAL THEORIES'),(43,12,'4th Semester-SPECTRUM:LITARATURE AND CONTEMPORARY '),(44,12,'4th Semester-MORDERN ENGLISH LITARATURE'),(45,12,'4th Semester-METHODOLOGY OF HUMANITIES'),(52,13,'4th Semester-ARABIC'),(53,13,'4th Semester-MALAYALAM'),(48,12,'4th Semester-HISTORY OF MASS MEDIA AND CORPORATE C'),(49,12,'4th Semester-MALAYALAM'),(50,12,'4th Semester-ARABIC'),(51,12,'4th Semester-ELECTRONIC MEDIA ,FUNDAMENTALS OF CIN'),(54,13,'4th Semester-SPECTRUM:LITARATURE AND CONTEMPORARY '),(55,13,'4th Semester-INDIAN CONSTITUTION AND POLITICS:POLI'),(56,13,'4th Semester-ABNORMAL PSYCHOLOGY AND PSYCHOLOGICAL'),(57,13,'4th Semester-SOCIAL RESEARCH METHODS'),(58,13,'4th Semester-LIFE SKILL DEVELOPMENT'),(59,11,'4th Semester-ARABIC'),(60,11,'4th Semester-ENTREPRENEURSHIP DEVELOPMENT '),(61,11,'4th Semester-BANKING AND INSURANCE'),(62,11,'4th Semester-COST ACCOUNTING'),(63,11,'4th Semester-CORPORATE REGULATIONS'),(64,11,'4th Semester-QUANTITATIVE TECHNIQUES FOR BUSINESS'),(65,18,'5th Semester-INDIAN WRITING IN ENGLISH'),(66,18,'5th Semester-METHODOLOGY OF LITERATURE'),(67,18,'5th Semester-INFORMATICS'),(68,18,'5th Semester-HUMAN RIGHTS IN INDIA'),(69,18,'5th Semester-LANGUAGE AND LINGUISTICS'),(70,19,'5th Semester-HUMAN RIGHTS IN INDIA'),(71,19,'5th Semester-SOCIOLOGY OF INDIAN SOCIETY'),(72,19,'5th Semester-THEORETICAL PERSPECTIVE IN SOCIOLOGY '),(73,19,'5th Semester-SOCIAL ANTHROPOLOGY'),(74,19,'5th Semester-RESEARCH METHODS AND STATISTICS'),(109,26,'5th Semester-FINANCIAL MARKETS AND SERVICES'),(85,26,'5th Semester-HUMAN RIGHTS IN INDIA'),(86,26,'5th Semester-ACCOUNTING FOR MANAGEMENT'),(87,26,'5th Semester-BUSINESS RESEARCH METHODS'),(94,26,'5th Semester-INCOME TAX LAW AND ACCOUNTS'),(89,26,'5th Semester-CO-OPERATIVE THEORY AND PRACTICE'),(90,26,'5th Semester-LEGAL ENVIRONMENT FOR CO-OPERATIVES'),(92,26,'5th Semester-FINANCE'),(93,26,'5th Semester-COMPUTER APPLICATION'),(95,18,'6th Semester-LITERARY CRITICISM AND THEORY '),(96,18,'6th Semester-LITERATURE IN ENGLISH:AMERICAN AND PO'),(97,18,'6th Semester-WRITING FOR THE MEDIA'),(98,18,'6th Semester-WORLD CLASSICS IN TRANSLATION'),(99,18,'6th Semester-WOMENS WRITING'),(100,19,'6th Semester-ENVIRONMENT AND SOCIETY'),(101,19,'6th Semester-MASS MEDIA AND SOCIETY'),(102,19,'6th Semester-WOMEN CONTEMPORARY SOCIETY'),(103,19,'6th Semester-POPULATION AND SOCIETY'),(104,19,'6th Semester-SOCIOLOGY OF DEVELOPMENT'),(105,26,'6th Semester-INCOME TAX AND GST'),(106,26,'6th Semester-AUDITING AND CORPORATE GOVERNANCE'),(107,26,'6th Semester-INTERNATIONAL CO-OPERATIVE MOVEMENTS'),(108,26,'6th Semester-CO-OPERATIVE MANAGEMENT AND ADMINISTR'),(110,26,'5th Semester-FUNDAMENTALS OF INVESTMENTS'),(111,26,'5th Semester-BUSINESS INFORMATION SYSTEM '),(112,26,'5th Semester-COMPUTER APPLICATIONS IN BUSINESS'),(113,26,'6th Semester-FINANCIAL DERIVATIVES '),(114,26,'6th Semester-FINANCIAL MANAGEMENT'),(115,26,'6th Semester-OFFICE AUTOMATION TOOLS'),(116,26,'6th Semester-COMPUTERISED ACCOUNTING WITH TALLY'),(117,27,'LANGUAGE THROUGH LITERATURE'),(118,14,'DEVELOPING EMOTIONAL COMPETENCE '),(119,27,'PSYCHOLOGICAL DISORDERS'),(120,14,'SOCIOLOGICAL THEORIES'),(121,27,'READING SPEAKING SKILLS'),(122,27,'MANAGING STRESS/SCHOOL PSYCHOLOGY'),(123,14,'STATISTICAL METHODS AND PSYCHOLOGICAL RESEARCH'),(124,14,'METHODS OF SOCIOLOGICAL ENQUIRY'),(125,28,'SUBSTANCE ABUSE AND COUNSELLING'),(126,20,'ORGANISING CHILD CARE SERVICES'),(127,20,'PSYCHOPATHOLOGY'),(128,20,'SCHOOL PSYCHOLOGY'),(129,20,'PRACTICALS IN CLINICAL,COUNSELLING,INDUSTRIAL PSYC'),(130,20,'INTERNSHIP IN PSYCHOLOGY');
/*!40000 ALTER TABLE `subjects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teachers`
--

DROP TABLE IF EXISTS `teachers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `teachers` (
  `teacher_id` int(11) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(50) NOT NULL,
  `mobile_number` varchar(10) NOT NULL,
  `email_address` varchar(25) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`teacher_id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teachers`
--

LOCK TABLES `teachers` WRITE;
/*!40000 ALTER TABLE `teachers` DISABLE KEYS */;
INSERT INTO `teachers` (`teacher_id`, `full_name`, `mobile_number`, `email_address`, `status`, `username`, `password`) VALUES (1,'SNEHAJAN KK','9847472218','snehajankk@gmail.com',1,'teacher692','password692'),(2,'UMADEVI PC','7994754891','anandthayyil639@gmail.com',1,'teacher15','password15'),(3,'VIJAYA RAGHAVAN P K','9495510990','aamipoppi4@gmail.com',1,'teacher672','password672'),(4,'REENA  P','9895593121','reenaraji76@gmail.com',1,'teacher377','password377'),(5,'VIJITHA N','9746387202','vijithanmaya258@gmail.com',1,'teacher782','password782'),(6,'MOHAME IRSHAD V','9995141259','irshadvaliyakat@gmail.com',1,'teacher887','password887'),(7,'JAMSHEER PK','9567929012','jamsirpk@gmail.com',1,'teacher86','password86'),(8,'JASIR V','9847173614','jasij8498@gmail.com',1,'teacher514','password514'),(9,'AKHILA K','9400920291','akhilakarukayil@gmail.com',1,'teacher254','password254'),(10,'SNEHAJAN K K','9847472218','snehajankk@gmail.com',1,'teacher977','password977'),(11,'SHIBINA. N','8606727269','shibinanshibi@gmail.com',1,'teacher662','password662'),(12,'SADIQ ALI. M','9656402710','sadiqmangalath@gmil.com',1,'teacher447','password447'),(13,'BINO C DAS','9605158703','binocdas@gmail.com',1,'teacher623','password623'),(14,'Rajeev Vengoli','9446100338','rajeevvengolikkm@gmail.co',1,'teacher178','password178'),(15,'Subair Molanthala ','9526421989','subairmolanthala@gmail.co',1,'teacher517','password517');
/*!40000 ALTER TABLE `teachers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'sacris_web'
--

--
-- Dumping routines for database 'sacris_web'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-07-14 11:01:30
